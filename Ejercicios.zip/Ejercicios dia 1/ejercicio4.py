nombre = input("Cómo te llamas?\n")
print("Hola " + nombre )