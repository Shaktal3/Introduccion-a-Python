print("Área del cuadrado")
lado = float(input("Introduce la longitud del lado:"))
print ("El área del cuadrado de lado", lado, "es:", lado*lado)