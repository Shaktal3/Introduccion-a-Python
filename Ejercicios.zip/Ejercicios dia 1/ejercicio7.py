print("Longitud de circunferencia y área del círculo")
radio = int(input("Introduce el radio del círculo"))
print("La circunferencia es:", 2*3.14*radio, "y el área es:", 3.14*radio**2)