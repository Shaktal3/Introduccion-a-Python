print("Conversor de Farenheit a Celsius")
far = float(input("Introduce los grados farenheit:"))
cel = (far - 32)/1.8
print(far, "ºF son ", cel, "ºC", sep='')