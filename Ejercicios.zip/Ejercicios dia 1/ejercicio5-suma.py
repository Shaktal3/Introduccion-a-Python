numero1 = int(input("Introduce el primer número\n"))
numero2 = int(input("Introduce el segundo número\n"))
resultado = numero1 + numero2
print(f"El resultado de: {numero1} + {numero2} es {resultado}" )