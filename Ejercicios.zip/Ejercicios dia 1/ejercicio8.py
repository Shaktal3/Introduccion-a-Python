print("Conversor de Celsius a Farenheit")
celsius = float(input("Introduce los grados celsius:"))
far = 1.8*celsius + 32
print(celsius, "ºC son ", far, "ºF", sep='')