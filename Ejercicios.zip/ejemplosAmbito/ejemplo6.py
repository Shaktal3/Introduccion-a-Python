def subrutina():
    a=b
    print(a)
    return



a=4
b=3
subrutina()
print(a)
