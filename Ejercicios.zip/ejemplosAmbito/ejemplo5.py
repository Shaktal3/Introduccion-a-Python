def subrutina():
    print (a)
    a = 11
    return



a=10
subrutina()
print(a)



