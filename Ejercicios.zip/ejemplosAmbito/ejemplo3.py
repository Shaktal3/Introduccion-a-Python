def subrutina():
    global a
    a = 10
    print (a)
    return


a=33
subrutina()
print(a)




