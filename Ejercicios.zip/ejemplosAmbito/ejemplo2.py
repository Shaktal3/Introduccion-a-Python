def subrutina():
    global a
    print (a)
    a = 21
    return



subrutina()
a=20
print(a)




