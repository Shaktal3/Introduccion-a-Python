fichero = open('prueba.txt', 'w')

fichero.write("Hola, ¿qué tal?")

fichero.close()