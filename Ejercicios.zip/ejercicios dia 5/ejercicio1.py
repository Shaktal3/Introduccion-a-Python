entrada=''
while entrada.lower()!='s':
    entrada = input("Desea terminar el programa? s/n ")