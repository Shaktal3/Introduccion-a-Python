def area_circulo(radio:float) ->float:
    return 3.14*radio**2
