from ejercicio4 import *

def volumen_cilindro(radio:float, altura:float)->float:
    return area_circulo(radio) * altura